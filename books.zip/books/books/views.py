from django.shortcuts import render
from pymongo import MongoClient
from bson import ObjectId


def home(request):
    dic={}
    dic['Developer']='Khushi'
    dic['Shop']='KSZ'
    return render(request,"index.html",dic)

def addbook(request):
    return render(request,"addbook.html")

def books(request):
    msg=None
    if request.method=="POST":
     try:
         id=request.POST.get("_id")
         ti=request.POST.get("title")
         au=request.POST.get("author")
         ge=request.POST.get("genre")
         py=request.POST.get("published_year")
         i=request.POST.get("isbn")
         pa=request.POST.get("pages")
         la=request.POST.get("language")
         pu=request.POST.get("publisher")

         dic={}
         dic["_id"]=id
         dic['title']=ti
         dic['author']=au
         dic['genre']=ge
         dic["published_year"]=py
         dic["isbn"]=i
         dic["pages"]=pa
         dic["language"]=la
         dic["publisher"]=pu
         client=MongoClient("mongodb+srv://kszatale23:kszatale23@ksz-cluster.ab2sjej.mongodb.net/?retryWrites=true&w=majority&appName=KSZ-Cluster")
         db=client['books']
         coll = db["bookdet"]

         print(dic)
         coll.insert_one(dic)
         msg = "Book Added Successfully"
     except Exception as e:
            msg = f"Error in Insert: {str(e)}"

    context = {"result": msg}
    return render(request, "addstatus.html", context)

def search(request):
    if request.method == "POST":
        fid = request.POST.get("book")
        dic = {"_id": fid}  # Corrected the key here
        print(dic)
        client = MongoClient("mongodb+srv://kszatale23:kszatale23@ksz-cluster.ab2sjej.mongodb.net/?retryWrites=true&w=majority&appName=KSZ-Cluster")
        db = client['books']
        collection = db['bookdet']
        search_results = list(collection.find(dic))  # Convert cursor to list
        print(search_results)
        return render(request, "search.html", {"search_results": search_results})
    else:
        # Return an empty response if the method is not POST
        return render(request, "search.html")

def searchbook(request):
        client = MongoClient("mongodb+srv://kszatale23:kszatale23@ksz-cluster.ab2sjej.mongodb.net/?retryWrites=true&w=majority&appName=KSZ-Cluster")
        db=client["books"]
        collection = db["bookdet"]
        k={}
        for k in collection.find():
         print(k)
        return render(request,"searchbook.html",{'book':k})

def update(request):
   return render(request,"updatebook.html")

def updatebook(request):
    if request.method == "POST":
        try:
            id = request.POST.get("_id")
            ti = request.POST.get("title")
            au = request.POST.get("author")
            ge = request.POST.get("genre")
            py = request.POST.get("published_year")
            i = request.POST.get("isbn")
            pa = request.POST.get("pages")
            la = request.POST.get("language")
            pu = request.POST.get("publisher")

            client = MongoClient("mongodb+srv://kszatale23:kszatale23@ksz-cluster.ab2sjej.mongodb.net/?retryWrites=true&w=majority&appName=KSZ-Cluster")
            db = client['books']
            coll = db["bookdet"]

            # Find the document to update
            query = {"_id": id}
            update_data = {
                '$set': {
                    'title': ti,
                    'author': au,
                    'genre': ge,
                    'published_year': py,
                    'isbn': i,
                    'pages': pa,
                    'language': la,
                    'publisher': pu
                }
            }
            coll.update_one(query, update_data)

            msg = "Update Successful"
        except Exception as e:
            msg = f"Error in Update: {str(e)}"
    else:
        msg = "No data received for update"

    return render(request, "updatestatus.html", {"message": msg})

def delete(request):
   return render(request,"deletebook.html")

def deletebook(request):
    if request.method == "POST":
        try:
            id = request.POST.get('_id')

            client = MongoClient("mongodb+srv://kszatale23:kszatale23@ksz-cluster.ab2sjej.mongodb.net/?retryWrites=true&w=majority&appName=KSZ-Cluster")
            db = client['books']
            coll = db["bookdet"]

            # Find the document to delete
            query = {"_id": id}
            result = coll.delete_one(query)

            if result.deleted_count > 0:
                msg = "Book deleted successfully"
            else:
                msg = "Book not found"
        except Exception as e:
            msg = f"Error in deletion: {str(e)}"
    else:
        msg = "No data received for deletion"

    return render(request, "deletestatus.html", {"message": msg})

def allbook(request):
    client = MongoClient("mongodb+srv://kszatale23:kszatale23@ksz-cluster.ab2sjej.mongodb.net/?retryWrites=true&w=majority&appName=KSZ-Cluster")
    db = client["books"]
    collection = db["bookdet"]
    booksdata = list(collection.find())  # Fetch all books data
    return render(request, "allbook.html", {'booksdata': booksdata})